/**
 * SmartBot AI — Admin Dashboard Script
 * Handles: tab switching, stats loading, messages table,
 *          search, pagination, conversation detail view.
 */

/* ── DOM refs ──────────────────────────────────────────────── */
const navItems            = document.querySelectorAll(".admin-nav-item[data-tab]");
const panels              = document.querySelectorAll(".tab-panel");
const refreshBtn          = document.getElementById("refreshBtn");
const pageTitle           = document.getElementById("pageTitle");

// Overview
const totalConversations  = document.getElementById("totalConversations");
const totalMessages       = document.getElementById("totalMessages");
const userMessages        = document.getElementById("userMessages");
const botMessages         = document.getElementById("botMessages");
const convTableBody       = document.getElementById("convTableBody");
const convBadge           = document.getElementById("convBadge");

// Messages tab
const msgTableBody        = document.getElementById("msgTableBody");
const searchInput         = document.getElementById("searchInput");
const pagination          = document.getElementById("pagination");

// Conversations detail tab
const convDetail          = document.getElementById("convDetail");

/* ── State ─────────────────────────────────────────────────── */
let currentPage  = 1;
let searchQuery  = "";
let searchTimer  = null;

/* ══════════════════════════════════════════════════════════════
   TAB SWITCHING
══════════════════════════════════════════════════════════════ */
navItems.forEach(item => {
  item.addEventListener("click", e => {
    e.preventDefault();
    const tab = item.dataset.tab;
    switchTab(tab);
  });
});

function switchTab(tab) {
  navItems.forEach(i => i.classList.toggle("active", i.dataset.tab === tab));
  panels.forEach(p => p.classList.toggle("active", p.id === `tab-${tab}`));
  pageTitle.textContent = tab.charAt(0).toUpperCase() + tab.slice(1);
  if (tab === "overview")      loadOverview();
  else if (tab === "messages") loadMessages();
}

/* ══════════════════════════════════════════════════════════════
   OVERVIEW
══════════════════════════════════════════════════════════════ */
async function loadOverview() {
  try {
    const res  = await fetch("/api/admin/stats");
    const data = await res.json();

    // Animate count-up
    animateCount(totalConversations, data.total_conversations);
    animateCount(totalMessages,      data.total_messages);
    animateCount(userMessages,       data.user_messages);
    animateCount(botMessages,        data.bot_messages);

    // Recent conversations table
    convBadge.textContent = `${data.recent_conversations.length} recent`;

    if (!data.recent_conversations.length) {
      convTableBody.innerHTML = '<tr><td colspan="5" class="table-empty">No conversations yet — start chatting! 💬</td></tr>';
      return;
    }

    convTableBody.innerHTML = data.recent_conversations.map(conv => `
      <tr>
        <td><code>#${conv.id}</code></td>
        <td>${truncate(conv.session_id, 24)}</td>
        <td><span class="badge">${conv.message_count}</span></td>
        <td>${formatDate(conv.created_at)}</td>
        <td>
          <button class="btn btn-sm btn-ghost view-conv-btn"
                  data-id="${conv.id}">View</button>
        </td>
      </tr>
    `).join("");

    // Attach view-conversation handlers
    document.querySelectorAll(".view-conv-btn").forEach(btn => {
      btn.addEventListener("click", () => viewConversation(+btn.dataset.id));
    });

  } catch (err) {
    console.error("Stats error:", err);
    convTableBody.innerHTML = '<tr><td colspan="5" class="table-empty">Error loading data.</td></tr>';
  }
}

function animateCount(el, target) {
  if (!target) { el.textContent = "0"; return; }
  let current = 0;
  const step  = Math.ceil(target / 30);
  const timer = setInterval(() => {
    current = Math.min(current + step, target);
    el.textContent = current.toLocaleString();
    if (current >= target) clearInterval(timer);
  }, 30);
}

/* ══════════════════════════════════════════════════════════════
   MESSAGES TABLE
══════════════════════════════════════════════════════════════ */
async function loadMessages(page = 1) {
  currentPage = page;
  const url = `/api/admin/messages?page=${page}&search=${encodeURIComponent(searchQuery)}`;
  try {
    const res  = await fetch(url);
    const data = await res.json();

    if (!data.messages.length) {
      msgTableBody.innerHTML = '<tr><td colspan="4" class="table-empty">No messages found.</td></tr>';
      pagination.innerHTML = "";
      return;
    }

    msgTableBody.innerHTML = data.messages.map(m => `
      <tr>
        <td><code>#${m.id}</code></td>
        <td>
          <span class="sender-badge ${m.sender}">
            ${m.sender === "user" ? "👤 User" : "🤖 Bot"}
          </span>
        </td>
        <td>${truncate(m.content, 80)}</td>
        <td style="white-space:nowrap">${formatDate(m.timestamp)}</td>
      </tr>
    `).join("");

    renderPagination(data.page, data.pages);

  } catch (err) {
    msgTableBody.innerHTML = '<tr><td colspan="4" class="table-empty">Error loading messages.</td></tr>';
  }
}

function renderPagination(current, total) {
  if (total <= 1) { pagination.innerHTML = ""; return; }

  let html = "";
  for (let i = 1; i <= total; i++) {
    html += `<button class="page-btn ${i === current ? "active" : ""}"
                     data-page="${i}">${i}</button>`;
  }
  pagination.innerHTML = html;

  pagination.querySelectorAll(".page-btn").forEach(btn => {
    btn.addEventListener("click", () => loadMessages(+btn.dataset.page));
  });
}

// Debounced search
searchInput.addEventListener("input", () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    searchQuery = searchInput.value.trim();
    loadMessages(1);
  }, 350);
});

/* ══════════════════════════════════════════════════════════════
   CONVERSATION DETAIL
══════════════════════════════════════════════════════════════ */
async function viewConversation(id) {
  // Switch to Conversations tab
  switchTab("conversations");

  convDetail.innerHTML = '<p style="padding:20px;color:var(--text-3)">Loading…</p>';

  try {
    const res  = await fetch(`/api/admin/conversation/${id}`);
    const data = await res.json();

    if (!data.messages.length) {
      convDetail.innerHTML = `<p style="padding:20px;color:var(--text-3)">No messages in conversation #${id}</p>`;
      return;
    }

    convDetail.className = "conv-detail-messages";
    convDetail.innerHTML = data.messages.map(m => `
      <div class="conv-detail-msg ${m.sender}">
        <div style="font-size:1.2rem">${m.sender === "bot" ? "🤖" : "👤"}</div>
        <div>
          <div class="conv-detail-bubble">${escapeHtml(m.content)}</div>
          <div class="conv-detail-meta">${formatDate(m.timestamp)}</div>
        </div>
      </div>
    `).join("");

  } catch (err) {
    convDetail.innerHTML = `<p style="padding:20px;color:var(--text-3)">Error loading conversation.</p>`;
  }
}

/* ══════════════════════════════════════════════════════════════
   REFRESH BUTTON
══════════════════════════════════════════════════════════════ */
refreshBtn.addEventListener("click", () => {
  const activeTab = document.querySelector(".admin-nav-item.active")?.dataset.tab;
  if (activeTab === "overview")      loadOverview();
  else if (activeTab === "messages") loadMessages(currentPage);

  // Spin animation
  refreshBtn.style.transform = "rotate(360deg)";
  refreshBtn.style.transition = "transform .5s ease";
  setTimeout(() => {
    refreshBtn.style.transform = "";
    refreshBtn.style.transition = "";
  }, 500);
});

/* ══════════════════════════════════════════════════════════════
   HELPERS
══════════════════════════════════════════════════════════════ */
function truncate(str, len) {
  if (!str) return "—";
  return str.length > len ? str.slice(0, len) + "…" : str;
}

function formatDate(ts) {
  if (!ts) return "—";
  try {
    return new Date(ts).toLocaleString([], {
      month: "short", day: "numeric",
      hour: "2-digit", minute: "2-digit"
    });
  } catch { return ts; }
}

function escapeHtml(text) {
  if (!text) return "";
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\n/g, "<br>");
}

/* ── Initial load ──────────────────────────────────────────── */
loadOverview();
