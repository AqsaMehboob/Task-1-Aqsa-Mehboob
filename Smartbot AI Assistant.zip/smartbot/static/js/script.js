/**
 * SmartBot AI — Chat Interface Script
 * Handles: messaging, dark mode, clear chat, download, typing animation,
 *          auto-grow textarea, session management, markdown rendering.
 */

/* ── Session ID (persisted) ────────────────────────────────── */
const SESSION_ID = (() => {
  let id = sessionStorage.getItem("smartbot_session");
  if (!id) {
    id = "session_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8);
    sessionStorage.setItem("smartbot_session", id);
  }
  return id;
})();

/* ── DOM refs ──────────────────────────────────────────────── */
const app             = document.getElementById("app");
const chatWindow      = document.getElementById("chatWindow");
const messagesList    = document.getElementById("messagesList");
const welcomeScreen   = document.getElementById("welcomeScreen");
const userInput       = document.getElementById("userInput");
const sendBtn         = document.getElementById("sendBtn");
const typingIndicator = document.getElementById("typingIndicator");
const darkModeToggle  = document.getElementById("darkModeToggle");
const sunIcon         = document.getElementById("sunIcon");
const moonIcon        = document.getElementById("moonIcon");
const clearChatBtn    = document.getElementById("clearChatBtn");
const downloadBtn     = document.getElementById("downloadBtn");
const sidebarOpen     = document.getElementById("sidebarOpen");
const sidebarClose    = document.getElementById("sidebarClose");
const sidebar         = document.getElementById("sidebar");
const confirmModal    = document.getElementById("confirmModal");
const cancelClear     = document.getElementById("cancelClear");
const confirmClear    = document.getElementById("confirmClear");
const newChatBtn      = document.getElementById("newChatBtn");

/* ── In-memory chat log ────────────────────────────────────── */
let chatHistory = []; // { sender, content, timestamp }

/* ══════════════════════════════════════════════════════════════
   DARK MODE
══════════════════════════════════════════════════════════════ */
function applyTheme(dark) {
  document.documentElement.classList.toggle("dark", dark);
  document.body.classList.toggle("dark", dark);
  if (dark) { sunIcon.style.display = "none"; moonIcon.style.display = ""; }
  else       { sunIcon.style.display = "";     moonIcon.style.display = "none"; }
  localStorage.setItem("smartbot_theme", dark ? "dark" : "light");
}

darkModeToggle.addEventListener("click", () => {
  const isDark = document.body.classList.contains("dark");
  applyTheme(!isDark);
});

// Restore saved theme
applyTheme(localStorage.getItem("smartbot_theme") === "dark");

/* ══════════════════════════════════════════════════════════════
   SIDEBAR TOGGLE (mobile)
══════════════════════════════════════════════════════════════ */
const overlay = document.createElement("div");
overlay.className = "sidebar-overlay";
document.body.appendChild(overlay);

function openSidebar()  { sidebar.classList.add("open"); overlay.classList.add("visible"); }
function closeSidebar() { sidebar.classList.remove("open"); overlay.classList.remove("visible"); }

sidebarOpen.addEventListener("click", openSidebar);
sidebarClose.addEventListener("click", closeSidebar);
overlay.addEventListener("click", closeSidebar);

/* ══════════════════════════════════════════════════════════════
   AUTO-GROW TEXTAREA
══════════════════════════════════════════════════════════════ */
userInput.addEventListener("input", () => {
  userInput.style.height = "auto";
  userInput.style.height = Math.min(userInput.scrollHeight, 140) + "px";
  sendBtn.disabled = !userInput.value.trim();
});

/* ══════════════════════════════════════════════════════════════
   MARKDOWN-LITE RENDERER
══════════════════════════════════════════════════════════════ */
function renderMarkdown(text) {
  // Escape HTML first
  let html = text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

  // Code blocks (```…```)
  html = html.replace(/```([\s\S]*?)```/g, "<pre><code>$1</code></pre>");

  // Inline code
  html = html.replace(/`([^`]+)`/g, "<code>$1</code>");

  // Bold **text**
  html = html.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");

  // Italic *text*
  html = html.replace(/\*(.+?)\*/g, "<em>$1</em>");

  // Bullet lists: lines starting with •, -, *
  html = html.replace(/^[•\-] (.+)$/gm, "<li>$1</li>");
  html = html.replace(/(<li>[\s\S]*?<\/li>)/g, "<ul>$1</ul>");

  // Numbered lists
  html = html.replace(/^\d+\. (.+)$/gm, "<li>$1</li>");

  // Newlines → <br>
  html = html.replace(/\n/g, "<br>");

  return html;
}

/* ══════════════════════════════════════════════════════════════
   APPEND MESSAGE TO UI
══════════════════════════════════════════════════════════════ */
function appendMessage(sender, content, timestamp) {
  // Hide welcome screen on first message
  if (welcomeScreen.style.display !== "none") {
    welcomeScreen.style.display = "none";
  }

  const time = timestamp
    ? new Date(timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    : new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

  const row = document.createElement("div");
  row.className = `msg-row ${sender}`;

  const avatarContent = sender === "bot" ? "🤖" : "You";

  row.innerHTML = `
    <div class="msg-avatar">${avatarContent}</div>
    <div class="msg-body">
      <div class="msg-bubble">${sender === "bot" ? renderMarkdown(content) : escapeHtml(content)}</div>
      <span class="msg-meta">${time}</span>
    </div>
  `;

  messagesList.appendChild(row);
  scrollToBottom();

  // Track in memory
  chatHistory.push({ sender, content, timestamp: timestamp || new Date().toISOString() });
}

function escapeHtml(text) {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\n/g, "<br>");
}

/* ══════════════════════════════════════════════════════════════
   SCROLL
══════════════════════════════════════════════════════════════ */
function scrollToBottom() {
  chatWindow.scrollTo({ top: chatWindow.scrollHeight, behavior: "smooth" });
}

/* ══════════════════════════════════════════════════════════════
   TYPING INDICATOR
══════════════════════════════════════════════════════════════ */
function showTyping() {
  typingIndicator.classList.add("visible");
  scrollToBottom();
}
function hideTyping() {
  typingIndicator.classList.remove("visible");
}

/* ══════════════════════════════════════════════════════════════
   SEND MESSAGE
══════════════════════════════════════════════════════════════ */
async function sendMessage(messageOverride) {
  const text = (messageOverride || userInput.value).trim();
  if (!text) return;

  // Clear input
  userInput.value = "";
  userInput.style.height = "auto";
  sendBtn.disabled = true;

  // Append user bubble
  appendMessage("user", text);

  // Show typing animation (random 600–1400ms for realism)
  showTyping();
  const thinkTime = 600 + Math.random() * 800;

  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text, session_id: SESSION_ID }),
    });

    if (!res.ok) throw new Error("Server error " + res.status);
    const data = await res.json();

    await delay(thinkTime);
    hideTyping();
    appendMessage("bot", data.response, data.timestamp);

  } catch (err) {
    await delay(thinkTime);
    hideTyping();
    appendMessage("bot", "⚠️ Oops! I couldn't connect to the server. Please ensure Flask is running and try again.");
    console.error("Chat error:", err);
  }
}

const delay = ms => new Promise(r => setTimeout(r, ms));

/* ── Send triggers ─────────────────────────────────────────── */
sendBtn.addEventListener("click", () => sendMessage());

userInput.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

/* ── Suggestion chips ──────────────────────────────────────── */
document.querySelectorAll(".suggestion-chip").forEach(chip => {
  chip.addEventListener("click", () => {
    const msg = chip.dataset.msg;
    sendMessage(msg);
  });
});

/* ══════════════════════════════════════════════════════════════
   CLEAR CHAT
══════════════════════════════════════════════════════════════ */
clearChatBtn.addEventListener("click", () => {
  confirmModal.classList.add("open");
});

cancelClear.addEventListener("click", () => {
  confirmModal.classList.remove("open");
});

confirmClear.addEventListener("click", () => {
  confirmModal.classList.remove("open");
  messagesList.innerHTML = "";
  chatHistory = [];
  welcomeScreen.style.display = "";   // Show welcome again
});

/* ══════════════════════════════════════════════════════════════
   DOWNLOAD CHAT
══════════════════════════════════════════════════════════════ */
downloadBtn.addEventListener("click", () => {
  if (!chatHistory.length) {
    alert("No messages to download yet!");
    return;
  }

  const lines = [
    "SmartBot AI — Chat Export",
    "=" .repeat(50),
    `Session ID: ${SESSION_ID}`,
    `Exported at: ${new Date().toLocaleString()}`,
    "=".repeat(50),
    "",
  ];

  chatHistory.forEach(({ sender, content, timestamp }) => {
    const label = sender === "user" ? "You" : "SmartBot";
    const time  = new Date(timestamp).toLocaleString();
    lines.push(`[${time}] ${label}:`);
    lines.push(content);
    lines.push("");
  });

  const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement("a");
  a.href     = url;
  a.download = `smartbot_chat_${Date.now()}.txt`;
  a.click();
  URL.revokeObjectURL(url);
});

/* ══════════════════════════════════════════════════════════════
   NEW CHAT
══════════════════════════════════════════════════════════════ */
newChatBtn.addEventListener("click", () => {
  messagesList.innerHTML = "";
  chatHistory = [];
  welcomeScreen.style.display = "";
  closeSidebar();
});

/* ══════════════════════════════════════════════════════════════
   LOAD HISTORY on page load
══════════════════════════════════════════════════════════════ */
async function loadHistory() {
  try {
    const res  = await fetch(`/api/history?session_id=${SESSION_ID}&limit=50`);
    const data = await res.json();
    if (data.messages && data.messages.length) {
      data.messages.forEach(m => appendMessage(m.sender, m.content, m.timestamp));
    }
  } catch (e) {
    // Silently fail — chat will still work
  }
}

loadHistory();
