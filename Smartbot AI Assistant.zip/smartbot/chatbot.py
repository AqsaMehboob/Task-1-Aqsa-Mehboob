"""
SmartBot AI Assistant - Rule-Based Chatbot Engine
Implements nested rule-based logic for intelligent responses
"""

import random
import re
from datetime import datetime


class SmartBot:
    """
    Rule-based chatbot with nested conditional logic.
    Handles greetings, FAQs, programming queries, AI topics, and more.
    """

    def __init__(self):
        self.name = "SmartBot"
        self.version = "1.0.0"

        # ── Jokes bank ──────────────────────────────────────────────
        self.jokes = [
            "Why do programmers prefer dark mode? Because light attracts bugs! 🐛",
            "How many programmers does it take to change a light bulb? None — that's a hardware problem! 💡",
            "Why did the developer go broke? Because he used up all his cache! 💸",
            "What's a computer's favorite snack? Microchips! 🍟",
            "Why do Java developers wear glasses? Because they don't C#! 👓",
            "A SQL query walks into a bar, walks up to two tables and asks… 'Can I join you?' 🍺",
            "Why was the JavaScript developer sad? Because he didn't know how to null his feelings! 😢",
            "What do you call a programmer from Finland? Nerdic! 🇫🇮",
        ]

        # ── Motivational quotes ──────────────────────────────────────
        self.quotes = [
            "The only way to do great work is to love what you do. — Steve Jobs 🍎",
            "Code is like humor. When you have to explain it, it's bad. — Cory House 💬",
            "First, solve the problem. Then, write the code. — John Johnson 🧩",
            "Experience is the name everyone gives to their mistakes. — Oscar Wilde ✨",
            "The best error message is the one that never shows up. — Thomas Fuchs 🚀",
            "Simplicity is the soul of efficiency. — Austin Freeman ⚡",
            "Talk is cheap. Show me the code. — Linus Torvalds 💻",
            "Programs must be written for people to read, and only incidentally for machines to execute. — SICP 📖",
        ]

    # ────────────────────────────────────────────────────────────────
    # Helper: keyword matching (word-boundary aware)
    # ────────────────────────────────────────────────────────────────
    def _contains(self, text: str, keywords: list) -> bool:
        """
        Return True if any keyword matches in text.
        Short keywords (<=4 chars) are matched as whole words to avoid
        false positives like "hi" inside "machine".
        """
        for kw in keywords:
            if len(kw) <= 4:
                if re.search(r"\b" + re.escape(kw) + r"\b", text):
                    return True
            else:
                if kw in text:
                    return True
        return False

    # ────────────────────────────────────────────────────────────────
    # Core response engine
    # ────────────────────────────────────────────────────────────────
    def get_response(self, user_input: str) -> str:
        """
        Main dispatcher — applies rule-based logic with nested conditions.
        Returns a string response for the given user_input.
        """
        text = user_input.lower().strip()

        # ── 1. Greetings ─────────────────────────────────────────────
        if self._contains(text, ["hello", "hi", "hey", "hiya", "howdy"]):
            return self._greeting_response(text)

        if self._contains(text, ["good morning"]):
            return "Good morning! ☀️ Hope your day is off to a great start. I'm SmartBot, ready to assist you!"

        if self._contains(text, ["good evening"]):
            return "Good evening! 🌙 How can I make your evening more productive? I'm here to help!"

        if self._contains(text, ["good night"]):
            return "Good night! 🌟 Rest well and come back tomorrow — I'll be right here!"

        # ── 2. Exit commands ──────────────────────────────────────────
        if self._contains(text, ["bye", "goodbye", "exit", "quit", "see you", "farewell"]):
            return "Goodbye! 👋 It was great chatting with you. Come back anytime — I'm always here! 😊"

        # ── 3. Help ───────────────────────────────────────────────────
        if self._contains(text, ["help", "what can you do", "commands", "options", "capabilities"]):
            return self._help_response()

        # ── 4. Bot identity ───────────────────────────────────────────
        if self._contains(text, ["your name", "who are you", "what are you", "introduce yourself"]):
            return ("I'm **SmartBot AI** 🤖, your intelligent assistant! "
                    "I'm a rule-based AI built with Python & Flask to help you with programming, "
                    "AI concepts, career advice, jokes, and much more. Ask me anything!")

        if self._contains(text, ["how are you", "how do you do", "how's it going", "how are things"]):
            return ("I'm doing fantastic, thanks for asking! 😊 "
                    "As an AI, I'm always at 100% — fuelled by curiosity and your great questions. "
                    "How about YOU? What can I help you with today?")

        # ── 5. Creator / About ────────────────────────────────────────
        if self._contains(text, ["who made you", "who created you", "who built you", "who is your creator"]):
            return ("I was created by a talented developer as a **Rule-Based AI Chatbot** project 💻. "
                    "Built with Python (Flask), SQLite, HTML, CSS & JavaScript — a full-stack AI demo!")

        # ── 6. Age / Version ──────────────────────────────────────────
        if self._contains(text, ["how old are you", "your age", "your version", "which version"]):
            return f"I'm SmartBot version **{self.version}** 🚀 — freshly deployed and ready to learn alongside you!"

        # ── 7. Programming (nested) ───────────────────────────────────
        if self._contains(text, ["programming", "coding", "code", "developer", "software", "language"]):
            return self._programming_response(text)

        # ── 8. AI / ML (nested) ───────────────────────────────────────
        if self._contains(text, ["artificial intelligence", "ai", "machine learning", "ml", "deep learning",
                                  "neural network", "chatbot", "nlp", "natural language"]):
            return self._ai_response(text)

        # ── 9. Database ───────────────────────────────────────────────
        if self._contains(text, ["database", "sql", "sqlite", "mysql", "postgresql", "mongodb", "nosql"]):
            return self._database_response(text)

        # ── 10. Web development ───────────────────────────────────────
        if self._contains(text, ["web", "html", "css", "javascript", "react", "frontend",
                                   "backend", "fullstack", "flask", "django", "node"]):
            return self._web_response(text)

        # ── 11. Career / Internship ───────────────────────────────────
        if self._contains(text, ["internship", "job", "career", "interview", "resume", "cv",
                                   "hire", "work experience", "placement", "fresher"]):
            return self._career_response(text)

        # ── 12. Study / Learning ──────────────────────────────────────
        if self._contains(text, ["learn", "study", "course", "tutorial", "resources", "book",
                                   "roadmap", "how to start", "beginner"]):
            return self._learning_response(text)

        # ── 13. Jokes ─────────────────────────────────────────────────
        if self._contains(text, ["joke", "funny", "laugh", "humor", "lol", "haha", "make me laugh"]):
            return f"Here's one for you 😄\n\n{random.choice(self.jokes)}"

        # ── 14. Motivation / Quotes ───────────────────────────────────
        if self._contains(text, ["motivat", "quote", "inspire", "inspiration", "encourage",
                                   "sad", "depressed", "upset", "lost"]):
            return f"Here's a thought to lift you up 💪\n\n*\"{random.choice(self.quotes)}\"*"

        # ── 15. Time / Date ───────────────────────────────────────────
        if self._contains(text, ["time", "date", "today", "what day", "current time"]):
            now = datetime.now()
            return (f"The current date and time is:\n"
                    f"📅 **{now.strftime('%A, %B %d, %Y')}**\n"
                    f"⏰ **{now.strftime('%I:%M %p')}**")

        # ── 16. Math / Calculation ────────────────────────────────────
        if self._contains(text, ["calculate", "math", "compute", "what is", "solve"]):
            return self._math_response(text)

        # ── 17. Thanks ────────────────────────────────────────────────
        if self._contains(text, ["thank", "thanks", "appreciate", "awesome", "great", "good bot"]):
            return ("You're very welcome! 😊 That's what I'm here for. "
                    "Is there anything else I can help you with?")

        # ── 18. Fallback ──────────────────────────────────────────────
        return self._fallback_response(text)

    # ────────────────────────────────────────────────────────────────
    # Sub-handlers
    # ────────────────────────────────────────────────────────────────

    def _greeting_response(self, text: str) -> str:
        hour = datetime.now().hour
        if hour < 12:
            time_greeting = "Good morning"
        elif hour < 17:
            time_greeting = "Good afternoon"
        else:
            time_greeting = "Good evening"

        return (f"{time_greeting}! 👋 I'm **SmartBot AI**, your intelligent assistant!\n\n"
                "I can help you with:\n"
                "• 💻 Programming & coding questions\n"
                "• 🤖 AI & machine learning topics\n"
                "• 🎓 Career & internship advice\n"
                "• 😄 Jokes & motivational quotes\n"
                "• And much more!\n\n"
                "What would you like to explore today?")

    def _help_response(self) -> str:
        return (
            "Here's what I can do for you 🚀\n\n"
            "**Conversational**\n"
            "• Greet me — say hello, hi, hey\n"
            "• Ask how I am\n"
            "• Ask my name or who made me\n\n"
            "**Technical Topics**\n"
            "• Programming (Python, Java, C++, JS…)\n"
            "• Artificial Intelligence & ML\n"
            "• Web Development (HTML/CSS/JS/Flask)\n"
            "• Databases & SQL\n\n"
            "**Career & Learning**\n"
            "• Internship & job advice\n"
            "• Learning roadmaps & resources\n"
            "• Interview preparation tips\n\n"
            "**Fun & Motivation**\n"
            "• Tell me a joke 😄\n"
            "• Motivational quotes 💪\n"
            "• Current date & time\n\n"
            "Type anything and I'll do my best to help!"
        )

    def _programming_response(self, text: str) -> str:
        """Nested: detect specific language, then respond."""
        if self._contains(text, ["python"]):
            return (
                "🐍 **Python** is one of the best languages to learn!\n\n"
                "**Why Python?**\n"
                "• Simple, readable syntax — great for beginners\n"
                "• Dominant in AI/ML (TensorFlow, PyTorch, Scikit-learn)\n"
                "• Versatile: web dev, automation, data science, scripting\n\n"
                "**Getting Started:**\n"
                "1. Install Python from python.org\n"
                "2. Learn basics: variables, loops, functions\n"
                "3. Try Flask for web apps\n"
                "4. Explore pandas & numpy for data\n\n"
                "**Resources:** Python.org docs, Real Python, freeCodeCamp 📚"
            )

        if self._contains(text, ["java"]):
            return (
                "☕ **Java** — Write Once, Run Anywhere!\n\n"
                "**Key Strengths:**\n"
                "• Strongly typed — great for learning OOP\n"
                "• Powers Android development\n"
                "• Widely used in enterprise backend systems\n"
                "• Huge job market demand\n\n"
                "**Learning Path:**\n"
                "1. Learn OOP concepts (classes, inheritance, polymorphism)\n"
                "2. Study Java Collections & Streams\n"
                "3. Explore Spring Boot for web\n"
                "4. Build Android apps with Java/Kotlin\n\n"
                "**Resources:** Oracle Docs, Baeldung, JetBrains Academy 📖"
            )

        if self._contains(text, ["javascript", "js"]):
            return (
                "⚡ **JavaScript** — the language of the web!\n\n"
                "**Why JS?**\n"
                "• Only language that runs natively in browsers\n"
                "• Full-stack with Node.js on the backend\n"
                "• Enormous ecosystem (React, Vue, Angular, Next.js)\n"
                "• Essential for any web developer\n\n"
                "**Learning Path:**\n"
                "1. Fundamentals: variables, DOM, events, async\n"
                "2. ES6+ features: arrow functions, promises, modules\n"
                "3. Pick a framework: React or Vue\n"
                "4. Backend: Node.js + Express\n\n"
                "**Resources:** MDN Web Docs, javascript.info, The Odin Project 🌐"
            )

        if self._contains(text, ["c++", "cpp", "c plus"]):
            return (
                "⚙️ **C++** — performance at its finest!\n\n"
                "**Where C++ Shines:**\n"
                "• Game development (Unreal Engine)\n"
                "• System programming & OS development\n"
                "• Embedded systems & IoT\n"
                "• High-frequency trading\n\n"
                "**Core Concepts to Master:**\n"
                "1. Pointers & memory management\n"
                "2. Object-Oriented Programming\n"
                "3. STL (Standard Template Library)\n"
                "4. Templates & generic programming\n\n"
                "**Resources:** cplusplus.com, learncpp.com, Bjarne Stroustrup's book 📚"
            )

        if self._contains(text, ["rust"]):
            return (
                "🦀 **Rust** — safe, fast, and modern!\n\n"
                "Rust is beloved for memory safety without garbage collection. "
                "Used by Mozilla, Microsoft, Amazon, and even the Linux kernel. "
                "If you want systems-level performance with modern ergonomics, Rust is your language!"
            )

        # General programming response
        return (
            "💻 **Programming** is a superpower worth developing!\n\n"
            "**Popular Languages & Use Cases:**\n"
            "• 🐍 Python → AI/ML, data science, scripting\n"
            "• ⚡ JavaScript → Web (frontend + backend)\n"
            "• ☕ Java → Enterprise, Android\n"
            "• ⚙️ C++ → Systems, games, embedded\n"
            "• 🦀 Rust → Systems with memory safety\n"
            "• 💎 Swift → iOS/macOS development\n\n"
            "Ask me about a specific language and I'll give you a detailed guide!"
        )

    def _ai_response(self, text: str) -> str:
        """Nested: ML, chatbots, NLP, deep learning, or general AI."""
        if self._contains(text, ["machine learning", "ml"]):
            return (
                "🤖 **Machine Learning** — teaching machines from data!\n\n"
                "**Three Main Types:**\n"
                "• **Supervised** — learn from labelled data (classification, regression)\n"
                "• **Unsupervised** — find hidden patterns (clustering, dimensionality reduction)\n"
                "• **Reinforcement** — learn by reward/penalty (games, robotics)\n\n"
                "**Key Algorithms:**\n"
                "Linear Regression, Decision Trees, Random Forest, SVM, K-Means, Neural Networks\n\n"
                "**Python Libraries:** Scikit-learn, TensorFlow, PyTorch, Keras\n\n"
                "**Learning Path:** Statistics → Python → Scikit-learn → Deep Learning 🎯"
            )

        if self._contains(text, ["deep learning", "neural network"]):
            return (
                "🧠 **Deep Learning & Neural Networks**\n\n"
                "Deep Learning uses multi-layered neural networks to learn complex patterns:\n\n"
                "• **CNN** — image recognition & computer vision\n"
                "• **RNN/LSTM** — sequence data, time series, text\n"
                "• **Transformers** — state-of-the-art NLP (GPT, BERT)\n"
                "• **GAN** — generative models, synthetic data\n\n"
                "**Frameworks:** TensorFlow, PyTorch, Keras, JAX\n\n"
                "Deep learning powers voice assistants, self-driving cars, and models like me! 🚗"
            )

        if self._contains(text, ["chatbot", "bot", "conversational"]):
            return (
                "💬 **Chatbots** — bridging humans and machines!\n\n"
                "**Types of Chatbots:**\n"
                "• **Rule-Based** (like me!) — predefined if-else logic, fast & predictable\n"
                "• **Retrieval-Based** — pick best response from a dataset\n"
                "• **Generative AI** — LLMs like GPT-4, Claude, Gemini\n\n"
                "**I'm a Rule-Based bot** built with Python & Flask. "
                "For production-grade bots, explore Rasa, Dialogflow, or fine-tune an LLM.\n\n"
                "**Build Your Own:** Start with NLTK or spaCy for NLP, then advance to Transformers! 🚀"
            )

        if self._contains(text, ["nlp", "natural language"]):
            return (
                "📝 **Natural Language Processing (NLP)**\n\n"
                "NLP lets computers understand, interpret, and generate human language.\n\n"
                "**Core Tasks:**\n"
                "• Tokenization & stemming\n"
                "• Sentiment analysis\n"
                "• Named Entity Recognition (NER)\n"
                "• Machine translation\n"
                "• Text summarization & generation\n\n"
                "**Key Libraries:** NLTK, spaCy, Hugging Face Transformers\n\n"
                "**Exciting Models:** BERT, GPT-4, T5, LLaMA — all based on Transformers! 🤗"
            )

        # General AI
        return (
            "🤖 **Artificial Intelligence** — the frontier of computing!\n\n"
            "AI enables machines to simulate human intelligence:\n\n"
            "• 🧠 **Machine Learning** — learn from data\n"
            "• 👁️ **Computer Vision** — see and interpret images\n"
            "• 💬 **NLP** — understand and generate language\n"
            "• 🎮 **Reinforcement Learning** — learn by interaction\n"
            "• 🤖 **Robotics** — physical AI agents\n\n"
            "Ask me about Machine Learning, Deep Learning, NLP, or Chatbots for deep dives!"
        )

    def _database_response(self, text: str) -> str:
        if self._contains(text, ["sqlite"]):
            return (
                "🗄️ **SQLite** — lightweight yet powerful!\n\n"
                "SQLite is a serverless, file-based relational database perfect for:\n"
                "• Small to medium applications\n"
                "• Prototyping & development\n"
                "• Mobile apps (iOS & Android use it natively)\n"
                "• Embedded systems\n\n"
                "I use SQLite to store our conversation history right now! 💬"
            )
        if self._contains(text, ["mysql", "postgresql", "postgres"]):
            return (
                "🗄️ **Relational Databases**\n\n"
                "• **MySQL** — most popular open-source RDBMS, great for web apps\n"
                "• **PostgreSQL** — advanced features, full ACID compliance, JSON support\n"
                "• **SQLite** — serverless, file-based, perfect for development\n\n"
                "All use SQL (Structured Query Language). Learn SELECT, INSERT, UPDATE, DELETE, JOINs! 📚"
            )
        if self._contains(text, ["mongodb", "nosql"]):
            return (
                "📦 **NoSQL & MongoDB**\n\n"
                "NoSQL databases store data differently:\n"
                "• **MongoDB** — document store (JSON-like BSON)\n"
                "• **Redis** — in-memory key-value store\n"
                "• **Cassandra** — wide-column for massive scale\n"
                "• **Neo4j** — graph database\n\n"
                "Use NoSQL when you need flexible schemas, horizontal scaling, or non-tabular data! ⚡"
            )
        return (
            "🗄️ **Databases** — the backbone of every application!\n\n"
            "**Relational (SQL):** MySQL, PostgreSQL, SQLite, Oracle\n"
            "**NoSQL:** MongoDB, Redis, Cassandra, DynamoDB\n\n"
            "Key concepts: normalization, indexes, transactions, ACID properties, JOINs.\n\n"
            "Want to know more about a specific database? Just ask! 😊"
        )

    def _web_response(self, text: str) -> str:
        if self._contains(text, ["flask"]):
            return (
                "🌶️ **Flask** — Python's micro web framework!\n\n"
                "Flask is lightweight, flexible, and perfect for building web apps and APIs.\n\n"
                "**Core Features:**\n"
                "• Routing with @app.route()\n"
                "• Jinja2 templating\n"
                "• Built-in development server\n"
                "• SQLAlchemy ORM integration\n\n"
                "**Ideal For:** REST APIs, small to medium web apps, prototyping\n\n"
                "This very chatbot is built with Flask! 🚀"
            )
        if self._contains(text, ["react"]):
            return (
                "⚛️ **React** — UI development supercharged!\n\n"
                "React is Facebook's library for building component-based user interfaces.\n"
                "Virtual DOM makes updates blazing fast.\n\n"
                "**Key Concepts:** Components, JSX, State, Props, Hooks, Context API\n"
                "**Ecosystem:** Next.js, React Router, Redux, React Query\n\n"
                "Most in-demand frontend skill in 2024! 💼"
            )
        return (
            "🌐 **Web Development Stack**\n\n"
            "**Frontend:**\n"
            "• HTML5 — structure\n"
            "• CSS3 — styling (Flexbox, Grid, animations)\n"
            "• JavaScript — interactivity\n"
            "• React / Vue / Angular — modern frameworks\n\n"
            "**Backend:**\n"
            "• Python: Flask / Django\n"
            "• JavaScript: Node.js / Express\n"
            "• Java: Spring Boot\n\n"
            "**Databases:** PostgreSQL, MySQL, MongoDB, SQLite\n\n"
            "Ask me about a specific technology! 🎯"
        )

    def _career_response(self, text: str) -> str:
        if self._contains(text, ["internship"]):
            return (
                "🎓 **Internship Advice** from SmartBot!\n\n"
                "**How to Land Your First Internship:**\n"
                "1. Build 2-3 solid projects on GitHub\n"
                "2. Craft a clean, ATS-friendly resume\n"
                "3. Apply on LinkedIn, Internshala, AngelList, company websites\n"
                "4. Network — reach out to professionals on LinkedIn\n"
                "5. Practice DSA on LeetCode / HackerRank\n\n"
                "**During Your Internship:**\n"
                "• Ask questions — curiosity is valued\n"
                "• Deliver on time, communicate blockers\n"
                "• Build genuine relationships with your team\n"
                "• Document your learnings\n\n"
                "You've got this! 💪"
            )
        if self._contains(text, ["interview"]):
            return (
                "🎯 **Interview Preparation Guide**\n\n"
                "**Technical Rounds:**\n"
                "• Data Structures & Algorithms (LeetCode 150)\n"
                "• System Design basics (for senior roles)\n"
                "• Language-specific questions\n"
                "• Problem-solving walkthroughs\n\n"
                "**Behavioural (HR) Round:**\n"
                "• STAR method: Situation, Task, Action, Result\n"
                "• Prepare 5-6 strong stories from past experiences\n"
                "• Research the company thoroughly\n\n"
                "**Golden Tips:**\n"
                "✅ Think aloud while coding\n"
                "✅ Clarify requirements before solving\n"
                "✅ Communicate your approach first\n"
                "✅ Ask thoughtful questions at the end"
            )
        if self._contains(text, ["resume", "cv"]):
            return (
                "📄 **Resume / CV Tips**\n\n"
                "**Must-Have Sections:**\n"
                "• Contact info + LinkedIn + GitHub\n"
                "• Professional summary (2-3 lines)\n"
                "• Technical Skills (grouped by category)\n"
                "• Projects (most important for freshers!)\n"
                "• Education & certifications\n\n"
                "**Pro Tips:**\n"
                "✅ One page for < 5 years experience\n"
                "✅ Quantify achievements (e.g., 'reduced load time by 40%')\n"
                "✅ Use action verbs: Built, Developed, Designed, Optimized\n"
                "✅ Tailor it for each job description\n"
                "✅ Use ATS-friendly formatting (no tables/columns)\n\n"
                "**Free Tools:** Canva, Novoresume, Overleaf (LaTeX)"
            )
        return (
            "💼 **Career in Tech** — exciting times ahead!\n\n"
            "**High-Demand Roles:**\n"
            "• Full-Stack Developer\n"
            "• Data Scientist / ML Engineer\n"
            "• DevOps / Cloud Engineer\n"
            "• Cybersecurity Analyst\n"
            "• Product Manager\n\n"
            "**Key Steps:**\n"
            "1. Master fundamentals (DSA, OOP, SQL)\n"
            "2. Build real projects\n"
            "3. Contribute to open source\n"
            "4. Network actively\n"
            "5. Never stop learning!\n\n"
            "Ask me about resumes, interviews, or internships for specific tips! 🎯"
        )

    def _learning_response(self, text: str) -> str:
        return (
            "📚 **Learning Resources Handpicked by SmartBot**\n\n"
            "**Free Platforms:**\n"
            "• freeCodeCamp — web dev, Python, data science\n"
            "• The Odin Project — full-stack web dev\n"
            "• CS50 (Harvard) — best intro to CS ever\n"
            "• MIT OpenCourseWare — rigorous CS content\n"
            "• Kaggle — data science & ML with competitions\n\n"
            "**Premium (Worth It):**\n"
            "• Udemy (buy on sale!), Coursera, Pluralsight\n\n"
            "**Practice:**\n"
            "• LeetCode, HackerRank — DSA & algorithms\n"
            "• GitHub — build & share projects\n"
            "• Codewars, Exercism — coding challenges\n\n"
            "**Tip:** Build projects from day one. "
            "Reading without building is like watching gym videos without working out! 💪"
        )

    def _math_response(self, text: str) -> str:
        """Simple safe math evaluator for basic expressions."""
        import re
        # Try to extract a math expression
        expr = re.sub(r"[^0-9+\-*/().\s]", "", text)
        expr = expr.strip()
        if expr:
            try:
                result = eval(expr, {"__builtins__": {}})  # restricted eval
                return f"🧮 The result of `{expr}` is **{result}**"
            except Exception:
                pass
        return (
            "🧮 I can handle basic arithmetic! Try typing an expression like:\n"
            "• `25 * 4`\n"
            "• `(100 + 50) / 3`\n"
            "• `2 ** 10`\n\n"
            "For advanced math, I recommend WolframAlpha or Python's math library!"
        )

    def _fallback_response(self, text: str) -> str:
        suggestions = [
            "I'm not sure I understood that 🤔 Try asking about:\n"
            "• Programming languages (Python, Java, JavaScript…)\n"
            "• AI & Machine Learning\n"
            "• Web development\n"
            "• Career & internship advice\n"
            "• A joke or motivational quote\n\n"
            "Or type **help** to see everything I can do!",

            "Hmm, that's outside my current knowledge base 🤷‍♂️\n\n"
            "I specialise in tech topics! Try asking me about Python, "
            "machine learning, web dev, career tips, or just say **help**!",

            "I didn't quite catch that 😅 Could you rephrase it?\n\n"
            "I'm great at programming, AI, career advice, and fun! "
            "Type **help** for a full list of topics.",
        ]
        return random.choice(suggestions)
