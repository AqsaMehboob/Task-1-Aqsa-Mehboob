"""
SmartBot AI Assistant — Flask Application
Entry point: initialises DB, registers routes, serves frontend
"""

from flask import Flask, request, jsonify, render_template, g
import sqlite3
import os
from datetime import datetime
from chatbot import SmartBot

# ── App setup ────────────────────────────────────────────────────────
app = Flask(__name__)
app.config["SECRET_KEY"] = "smartbot-secret-2024"

DATABASE = os.path.join(os.path.dirname(__file__), "database.db")
bot = SmartBot()

# ── Database helpers ─────────────────────────────────────────────────

def get_db():
    """Open a database connection scoped to the current request."""
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row          # dict-like rows
    return db


@app.teardown_appcontext
def close_connection(exception):
    """Close DB connection after every request."""
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()


def init_db():
    """Create tables if they don't exist yet."""
    with app.app_context():
        db = get_db()
        db.executescript("""
            CREATE TABLE IF NOT EXISTS conversations (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id  TEXT NOT NULL,
                created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS messages (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id INTEGER NOT NULL,
                sender          TEXT NOT NULL CHECK(sender IN ('user','bot')),
                content         TEXT NOT NULL,
                timestamp       DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (conversation_id) REFERENCES conversations(id)
            );

            CREATE INDEX IF NOT EXISTS idx_messages_conv
                ON messages(conversation_id);

            CREATE INDEX IF NOT EXISTS idx_messages_ts
                ON messages(timestamp);
        """)
        db.commit()


# ── Public routes ────────────────────────────────────────────────────

@app.route("/")
def index():
    """Serve the main chat page."""
    return render_template("index.html")


@app.route("/admin")
def admin():
    """Serve the admin dashboard."""
    return render_template("admin.html")


@app.route("/api/chat", methods=["POST"])
def chat():
    """
    Receive a user message, get a bot response, persist both,
    and return JSON to the frontend.
    """
    data = request.get_json(force=True)
    user_message = (data.get("message") or "").strip()
    session_id   = data.get("session_id", "default")

    if not user_message:
        return jsonify({"error": "Empty message"}), 400

    db = get_db()

    # Ensure a conversation record exists for this session
    row = db.execute(
        "SELECT id FROM conversations WHERE session_id = ? ORDER BY id DESC LIMIT 1",
        (session_id,)
    ).fetchone()

    if row:
        conv_id = row["id"]
    else:
        cur = db.execute(
            "INSERT INTO conversations (session_id) VALUES (?)", (session_id,)
        )
        db.commit()
        conv_id = cur.lastrowid

    # Get bot response
    bot_response = bot.get_response(user_message)
    timestamp    = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Persist user message
    db.execute(
        "INSERT INTO messages (conversation_id, sender, content, timestamp) VALUES (?,?,?,?)",
        (conv_id, "user", user_message, timestamp)
    )
    # Persist bot response
    db.execute(
        "INSERT INTO messages (conversation_id, sender, content, timestamp) VALUES (?,?,?,?)",
        (conv_id, "bot", bot_response, timestamp)
    )
    db.commit()

    return jsonify({
        "response":  bot_response,
        "timestamp": timestamp,
        "status":    "success"
    })


@app.route("/api/history", methods=["GET"])
def get_history():
    """Return recent chat history for a session."""
    session_id = request.args.get("session_id", "default")
    limit      = min(int(request.args.get("limit", 50)), 200)

    db   = get_db()
    rows = db.execute("""
        SELECT m.sender, m.content, m.timestamp
        FROM messages m
        JOIN conversations c ON m.conversation_id = c.id
        WHERE c.session_id = ?
        ORDER BY m.timestamp DESC
        LIMIT ?
    """, (session_id, limit)).fetchall()

    messages = [dict(r) for r in reversed(rows)]
    return jsonify({"messages": messages, "count": len(messages)})


# ── Admin API routes ─────────────────────────────────────────────────

@app.route("/api/admin/stats", methods=["GET"])
def admin_stats():
    """Return aggregate statistics for the admin dashboard."""
    db = get_db()

    total_conv = db.execute("SELECT COUNT(*) FROM conversations").fetchone()[0]
    total_msg  = db.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
    user_msg   = db.execute(
        "SELECT COUNT(*) FROM messages WHERE sender='user'"
    ).fetchone()[0]
    bot_msg    = db.execute(
        "SELECT COUNT(*) FROM messages WHERE sender='bot'"
    ).fetchone()[0]

    # Recent conversations (last 20)
    recent_rows = db.execute("""
        SELECT c.id, c.session_id, c.created_at,
               COUNT(m.id) AS message_count
        FROM conversations c
        LEFT JOIN messages m ON m.conversation_id = c.id
        GROUP BY c.id
        ORDER BY c.created_at DESC
        LIMIT 20
    """).fetchall()

    return jsonify({
        "total_conversations": total_conv,
        "total_messages":      total_msg,
        "user_messages":       user_msg,
        "bot_messages":        bot_msg,
        "recent_conversations": [dict(r) for r in recent_rows]
    })


@app.route("/api/admin/messages", methods=["GET"])
def admin_messages():
    """Return paginated messages, with optional search."""
    search = request.args.get("search", "").strip()
    page   = max(int(request.args.get("page", 1)), 1)
    per    = 30
    offset = (page - 1) * per

    db = get_db()

    if search:
        query  = "SELECT * FROM messages WHERE content LIKE ? ORDER BY timestamp DESC LIMIT ? OFFSET ?"
        rows   = db.execute(query, (f"%{search}%", per, offset)).fetchall()
        total  = db.execute(
            "SELECT COUNT(*) FROM messages WHERE content LIKE ?", (f"%{search}%",)
        ).fetchone()[0]
    else:
        rows  = db.execute(
            "SELECT * FROM messages ORDER BY timestamp DESC LIMIT ? OFFSET ?",
            (per, offset)
        ).fetchall()
        total = db.execute("SELECT COUNT(*) FROM messages").fetchone()[0]

    return jsonify({
        "messages": [dict(r) for r in rows],
        "total":    total,
        "page":     page,
        "pages":    max(1, -(-total // per))   # ceiling division
    })


@app.route("/api/admin/conversation/<int:conv_id>", methods=["GET"])
def admin_conversation(conv_id):
    """Return all messages for a specific conversation."""
    db   = get_db()
    rows = db.execute(
        "SELECT * FROM messages WHERE conversation_id = ? ORDER BY timestamp",
        (conv_id,)
    ).fetchall()
    return jsonify({"messages": [dict(r) for r in rows], "conversation_id": conv_id})


# ── Bootstrap & run ──────────────────────────────────────────────────

init_db()

if __name__ == "__main__":
    print("🤖 SmartBot AI Assistant starting…")
    print("   Chat:  http://127.0.0.1:5000")
    print("   Admin: http://127.0.0.1:5000/admin")
    app.run(debug=True, host="0.0.0.0", port=5000)
